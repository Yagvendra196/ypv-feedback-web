export { default } from './Text'
export { TEXTVARIANT, TEXTCOLOR } from './constant'