import React from "react";
import { ListGroup, ListItem, Text, Icon } from "..";
import styles from "./SideBar.module.scss";
import { Link } from "react-router-dom";

const SideBar = () => {
  return (
    <div className={styles.navBar}>
      <div className={styles.p20}>
        <Text variant="lgText" color="primaryColor">
          YPV Spiritual Buddy
        </Text>
      </div>
      <div className={styles.line}></div>
      <div className={styles.p20}>
        <div className={styles.listItem}>
          <ListGroup variant="ul">
            <ListItem>
              <Icon type="dashboard" variant="icon_mlarge" />
              <Link to="/dashboard">Dashboard</Link>
            </ListItem>
            <ListItem>
              <Icon type="password" variant="icon_mlarge" />
              <Link to="/changepassword">Change Password</Link>
            </ListItem>
            <ListItem>
              <Icon type="logout" variant="icon_mlarge" />
              Logout
            </ListItem>
          </ListGroup>
        </div>
      </div>
    </div>
  );
};

export default SideBar;
