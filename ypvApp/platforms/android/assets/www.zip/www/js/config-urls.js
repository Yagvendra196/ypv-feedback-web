/* Web service urls */
var versionName = 2.0;
var _protocol = 'http';
//var wsBasePath = _protocol+"://"+"ypvhealing.com/feedback/"; //production server
// var wsBasePath = _protocol+"://"+"dev.galaxyweblinks.com/ypv-feedback/";
var wsBasePath = _protocol+"://"+"ypv-feedback.galaxyweblinks.in/"; // dev server //
//var wsBasePath = _protocol+"://"+"192.168.0.56/ypv-feedback/dev/"; //
// var wsBasePath = _protocol+"://"+"192.168.0.60/ypv-feedback/dev/";
// var wsBasePath = _protocol+"://"+"192.168.0.58/ypv-feedback/dev/";
//var wsBasePath = _protocol+"://"+"localhost/ypv-feedback/dev/";
var wsModule = "api/";
var wsBaseUrl = wsBasePath+wsModule;